import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the Marks of Student:");
    int marks = sc.nextInt();
    if(marks>=90)
    {
      System.out.println("Student Got A Grade");
    }
    
    else if(marks>=71)
    {
      System.out.println("Student Got B Grade");
    }
    
    else if(marks>=60)
    {
      System.out.println("Student Got C Grade");
    }
    
    else if(marks>=50)
    {
      System.out.println("Student Got A Grade");
    }
    else{
      System.out.println("!!!......Student is Fail......!!!");
    }
  }
}